﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoppuProjekti
{

    /*Tietueet tehty siten että osoitetiedot sekä työtiedot ovat osa Työntekijää
     * Tietoja on sen verran vähän että nämä olisi voinut tehdä yhdeksi struktiksi
     * mutta halusin haastaa itseäni ja kokeilla saanko nämä toimimaan näin.
     */
    public struct Tyontekija
    {
        private string etunimi;
        private string kutsumanimi;
        private string sukunimi;
        private string hetu;
        public Osoitetiedot osoite;
        public Tyotiedot Tiedot;
        public string Etunimi { get => etunimi; set => etunimi = value; }
        public string Kutsumanimi { get => kutsumanimi; set => kutsumanimi = value; }
        public string Sukunimi { get => sukunimi; set => sukunimi = value; }
        public string Hetu { get => hetu; set => hetu = value; }
        public string OsoiteKatu { get => osoite.Katuosoite; set => osoite.Katuosoite = value; }
        public string OsoiteNumero { get => osoite.Postinumero; set => osoite.Postinumero = value; }
        public string OsoiteTmp { get => osoite.Postitmp; set => osoite.Postitmp = value; }

        public string tyoNimike { get => Tiedot.Nimike; set => Tiedot.Nimike = value; }
        public string tyoyksikko { get => Tiedot.Yksikko; set => Tiedot.Yksikko = value; }
        public DateTime TyotAlkoi { get => Tiedot.TyoAlkoi; set => Tiedot.TyoAlkoi = value; }
        public DateTime TyotLoppui { get => Tiedot.TyoLoppui; set => Tiedot.TyoLoppui = value; }


        // Toiminto varmistaa että kenttään tulee viiva jos työsuhde on vielä voimassa.
        // Jos työ suhde on päättynyt se tuo loppumis päivämäärän
        public string Loppunut
        {
            get
            {
                if (Tiedot.Loppunut)
                    return TyotLoppui.ToString();
                else
                    return "-";
            }
        }
    }
    public struct Osoitetiedot
    {
        private string katuosoite;
        private string postinumero;
        private string postitmp;
        public string Katuosoite { get => katuosoite; set => katuosoite = value; }
        public string Postinumero { get => postinumero; set => postinumero = value; }
        public string Postitmp { get => postitmp; set => postitmp = value; }
    }
    public struct Tyotiedot
    {
        private string nimike;
        private string yksikko;
        private DateTime tyoAlkoi;
        private DateTime tyoLoppui;
        private bool loppunut;
        public string Nimike { get => nimike; set => nimike = value; }
        public string Yksikko { get => yksikko; set => yksikko = value; }
        public DateTime TyoAlkoi { get => tyoAlkoi; set => tyoAlkoi = value; }
        public DateTime TyoLoppui { get => tyoLoppui; set => tyoLoppui = value; }
        public bool Loppunut { get => loppunut; set => loppunut = value; }
    }

    public partial class Form1 : Form
    {

        /* Koska sovelluksessa on usempi paikka johon tiedostopolku pitää täyttää on parempi kovakoodata 
         * osoite tänne. samoin listat rivivalinta ja muokkaus osioita tarvitaan useammassa paikassa.
         */
        private List<Tyontekija> palkattava = new List<Tyontekija>();
        public DataTable Naytettava;
        private string toiminto;
        private string dir = @"c:/TempCrap/tyontekijat.json";
        private int Rivivalinta = -1;
        private bool muokkaus = false;

        // Funktio tekstikenttien tyhjennykseen
        private void tyhjennaKentat()
        {
            
            tbEtunimi.Text = "";
            tbKutsumanimi.Text = "";
            tbSukunimi.Text = "";
            tbHetu.Text = "";
            tbOsoite.Text = "";
            tbPostinro.Text = "";
            tbTmp.Text = "";
            tbNimike.Text = "";
            tbYksikko.Text = "";
            dtpAlkoi.Value = DateTime.Now;
            dtpLoppui.Value = DateTime.Now;
        }
        private bool Hetuoikein(string hetu, out string errormsg)
        {
            string varmenneluku ="";
            // ensin testataan onko henkilötunnus oikean mittainen
            if (hetu.Length == 11)
            {
                // Koska suomen henkilötunnukset eivät tunnista kaikkia kirjaimia (G, I, O, Q ja Z) pitää varmennetunnus
                //muodostaa eri tavoin eri luvuille. Sovellus hyväksyy pienet kirjamiet mutta tallentaa ne isoina kirjaimina.
                hetu = hetu.ToUpper();
                char.TryParse(hetu.Substring(10, 1), out char varmenne);
                if (varmenne >= 48 && varmenne <= 58)
                    varmenneluku = "" + ((int)varmenne - 48);
                else if (varmenne >= 65 && varmenne <= 70)
                    varmenneluku = "" + ((int)varmenne - 55);
                else if (varmenne == 72)
                    varmenneluku = "" + ((int)varmenne - 56);
                else if (varmenne >= 74 && varmenne <= 78)
                    varmenneluku = "" + ((int)varmenne - 57);
                else if (varmenne == 80)
                    varmenneluku = "" + ((int)varmenne - 58);
                else if (varmenne >= 82 && varmenne <= 89)
                    varmenneluku = "" + ((int)varmenne - 59);
                // henkilötunnuksesta napataan numerot erikseen ja testataan ne tunniste lukua vastaan niinkuin on ohjeistus
                // Ohjeistus jaa henkilötunnuksen numerot yhdistettynä luvulla 31 (120687-123T => 120687123 / 31
                // luvusta saadut desimaalit kerrotaan luvulla 31 ja pyöristetään lähimpään täyteen lukuun
                // tämän luvun on vastattava tunnistelukua.
                hetu = hetu.Substring(0, 6) + "" + hetu.Substring(7, 3);
                // testataan onko henkilötunnuksen osa mahdollista muuttaa desimaali muuttujaksi. 
                // Tämä kertoo onko seassa kirjaimia jolloin ei voida jatkaa
                bool testi = decimal.TryParse(hetu, out decimal testiluku);
                if (testi)
                {
                    // testiluku = pyöristys((testiluku/31-(testiluku/31 tuloksen täysluvut)*31)
                    testiluku = Math.Round(((testiluku / 31) - Math.Truncate(testiluku / 31)) * 31);
                    if (testiluku == int.Parse(varmenneluku))
                    {
                        errormsg = "";
                        return true;
                    }
                }

            }
            // 
            errormsg = "Henkilötunnus ei kelpaa";
            return false;
        }
       
        /* Tekstikenttien valdointi ja virheviestin tuottaminen.
         * Henkilötunnuksen validointi on huomioitu erillisella if rakenteella.
         */
        private void Validoikentta(object sender, CancelEventArgs e)
        {
            TextBox tb = (TextBox)sender;
            if (tb.Text == "")
            {
                this.epVirhe.SetError(tb, "Pakollinen kenttä!");
                e.Cancel = true;
            }
            if (tb == tbHetu)
            {


                if (!Hetuoikein(tb.Text, out string errormsg))
                {
                    e.Cancel = true;
                    tb.Select(0, tb.Text.Length);
                    epVirhe.SetError(tb, errormsg);
                }
            }
        }

        /* Tekstienttien valdoinnin onnistuessa tyhjennetään virheviestit ja tallennetaan toiminto loki tiedostoon
        *Loki tiedoston olisi voinut tallenttaa vasta käyttäjän tallentaessa työntekijän tiedot mutta näin jää tarkemmat 
        *tiedot käyttäjän tekemistä toimista
        */
        private void Validoitukentta(object sender, EventArgs e)
        {
            TextBox tb = (TextBox)sender;
            epVirhe.SetError(tb, "");
            string toiminto = "Tekstikenttaan: " + tb.Name.Substring(2, tb.Name.Length - 2) + " syotettiin: " + tb.Text;
            Tallennatoiminto(toiminto);
        }



        /* Tominto työntekijä listan tallennukseen.
         */
        public void TallennaTiedostoon(List<Tyontekija> tiedot, string dir)
        {
            try 
            { 
          
            string json = JsonConvert.SerializeObject(tiedot);
            File.WriteAllText(dir, json);
            }
            catch (Exception ex )
            {

                MessageBox.Show(ex.Message);
            }
}       
        /*Toiminto työntekijä listan avaamiseksi sovellukseen. 
         */
        public List<Tyontekija> HaeTiedostosta(List<Tyontekija> tiedot,string dir)
        {
            if (File.Exists(dir))
            {
                using (StreamReader sr = new StreamReader(dir))
                {
                    string json = sr.ReadToEnd();
                     tiedot = JsonConvert.DeserializeObject<List<Tyontekija>>(json);

                }
                
            }
                return tiedot;
        }

        /*Tomintojen vienti loki tiedostoon. Funktio ottaa sisäänsa toiminnon stringinä
         * funktio generoi käyttäjänimen enviroment luokalta ja päivämäärän.
         * Nämä tallentuvat log.txt tiedostoon.
         */
        public void Tallennatoiminto(string toiminto)
        {
            string kauttaja = Environment.UserName;
            try
            {
                string dir = @"c:/TempCrap/log.txt";
                FileStream fs = null;
                fs = new FileStream(dir, FileMode.Append );
                using (StreamWriter writer = new StreamWriter(fs))
                {
                    if (!File.Exists(dir))
                    {
                        File.Create(dir);
                    }
                    writer.WriteLine("Kayttaja: {0} toiminto: {1} Kellonaika: {2}", kauttaja, toiminto, DateTime.Now.ToString());
                }
                fs.Dispose();
               

            }

            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        /*Työntekijä lista tuodaan data tableen. Naytettava antaa nullrefrenssiä jos tiedostoa 
         * ei ole olemassa. on siis tarkistettava että tiedosto on olemassa ennen kuin toimintoa 
         * voidaan käyttää.
         */
        private void LisaaNakymaan(string dir)
        {
            if (File.Exists(dir)) 
            {     
                Naytettava.Rows.Clear();
                
                for (int i = 0; i < palkattava.Count; i++)
                {
                    DataRow Rivi = Naytettava.NewRow();
                    Rivi["Etunimi"] = palkattava[i].Etunimi;
                    Rivi["Kutsumanimi"] = palkattava[i].Kutsumanimi;
                    Rivi["Sukunimi"] = palkattava[i].Sukunimi;
                    Rivi["Henkilötunnus"] = palkattava[i].Hetu;
                    Rivi["Katuosoite"] = palkattava[i].OsoiteKatu;
                    Rivi["Postinumero"] = palkattava[i].OsoiteNumero;
                    Rivi["Postitoimipaikka"] = palkattava[i].OsoiteTmp;
                    Rivi["Nimike"] = palkattava[i].tyoNimike;
                    Rivi["Yksikkö"] = palkattava[i].tyoyksikko;
                    Rivi["Työsuhde Alkoi"] = palkattava[i].TyotAlkoi;
                    Rivi["Työsuhde Loppui"] = palkattava[i].Loppunut;
                    Naytettava.Rows.Add(Rivi);
                }

            }
        }
        



        public Form1()
        {
            InitializeComponent();


            dtpAlkoi.MaxDate = DateTime.Today.AddHours(24.00);
            dtpLoppui.MaxDate = DateTime.Today.AddHours(24.00);



            // Luodaan järjestettävä dataTable Työntekijänäkymään
            Naytettava = new DataTable();
            DataColumn Sarake;

            //Jokainen sarake pitää erikseen määrittää näkymää varten
            Sarake = new DataColumn();
            Sarake.DataType = System.Type.GetType("System.String");
            Sarake.ColumnName = "Etunimi";
            Naytettava.Columns.Add(Sarake);

            Sarake = new DataColumn();
            Sarake.DataType = System.Type.GetType("System.String");
            Sarake.ColumnName = "Kutsumanimi";
            Naytettava.Columns.Add(Sarake);

            Sarake = new DataColumn();
            Sarake.DataType = System.Type.GetType("System.String");
            Sarake.ColumnName = "Sukunimi";
            Naytettava.Columns.Add(Sarake);

            Sarake = new DataColumn();
            Sarake.DataType = System.Type.GetType("System.String");
            Sarake.ColumnName = "Henkilötunnus";
            Naytettava.Columns.Add(Sarake);

            Sarake = new DataColumn();
            Sarake.DataType = System.Type.GetType("System.String");
            Sarake.ColumnName = "Katuosoite";
            Naytettava.Columns.Add(Sarake);

            Sarake = new DataColumn();
            Sarake.DataType = System.Type.GetType("System.String");
            Sarake.ColumnName = "Postinumero";
            Naytettava.Columns.Add(Sarake);

            Sarake = new DataColumn();
            Sarake.DataType = System.Type.GetType("System.String");
            Sarake.ColumnName = "Postitoimipaikka";
            Naytettava.Columns.Add(Sarake);

            Sarake = new DataColumn();
            Sarake.DataType = System.Type.GetType("System.String");
            Sarake.ColumnName = "Nimike";
            Naytettava.Columns.Add(Sarake);

            Sarake = new DataColumn();
            Sarake.DataType = System.Type.GetType("System.String");
            Sarake.ColumnName = "Yksikkö";
            Naytettava.Columns.Add(Sarake);

            Sarake = new DataColumn();
            Sarake.DataType = System.Type.GetType("System.DateTime");
            Sarake.ColumnName = "Työsuhde Alkoi";
            Naytettava.Columns.Add(Sarake);

            Sarake = new DataColumn();
            Sarake.DataType = System.Type.GetType("System.String");
            Sarake.ColumnName = "Työsuhde Loppui";
            Naytettava.Columns.Add(Sarake);
            dgvLista.DataSource = Naytettava;

            palkattava = HaeTiedostosta(palkattava, dir);
            LisaaNakymaan(dir);
        }
        


        // toiminto työsuhteen päättymiseen liittyen. Näytetäänkö päivämäärä valitsin
        private void cb_Voimassa_CheckedChanged(object sender, EventArgs e)
        {
            if (!cbVoimassa.Checked)
                dtpLoppui.Visible = true;
            else
                dtpLoppui.Visible = false;
        }

        // Postinumero kentän tulee hyväksyä vain numeroita ja poisto näppäin
        private void tbPostinro_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != '\b')
                e.Handled = true;
        }

        /* Käyttäjän syöttäessä kenttään postinumeroa
         * Testataan löytyykö listasta valmiiksi postitoimipaikka
         * tämän löytyessä listasta syötetään se kenttään.
         * Sovelluksessa huomioitu vaun suomalaiset postinumerot jotka ovat pituudeltaan viisi numeroa.
         * */
        private void tbPostinro_KeyPress(object sender, KeyEventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {

           
            if (palkattava != null && tbPostinro.TextLength == i)
            {
                string vertaa = tbPostinro.Text;
                foreach (Tyontekija OsoiteNumero in palkattava)
                {
     
                        if (vertaa == OsoiteNumero.OsoiteNumero.Substring(0, i))
                        {
                            tbTmp.Text = OsoiteNumero.OsoiteTmp;
                        }
                    
                }
            }
            }
        }




        /* Ensin nappi tarkistaa että kaikki validoinnit on tehty eli onko kaikki tekstikentät lomakkeella täytetty.
         * Nappi lisää teksti kentät listaan. Tarkistaa onko työsuhde päättynyt syöttäen oikean 
         * tiedon. Tarkistaa onko kyseessä muokkaus vai lisäys ja muuttaa tai lisää työntekijä tietoja
         * Lopuksi Lisää toiminnon logiin ja tallentaa listan tiedostoon ja näyttää datatablessa muutokset.
         */
        private void btnTallenna_Click(object sender, EventArgs e)
        {
            try
            {

                if (ValidateChildren(ValidationConstraints.Enabled))
                {
                    Tyontekija tyontekija = new Tyontekija();
                    tyontekija.Etunimi = tbEtunimi.Text;
                    tyontekija.Kutsumanimi = tbKutsumanimi.Text;
                    tyontekija.Sukunimi = tbSukunimi.Text;
                    tyontekija.Hetu = tbHetu.Text;
                    Osoitetiedot osoite = new Osoitetiedot();
                    osoite.Katuosoite = tbOsoite.Text;
                    osoite.Postinumero = tbPostinro.Text;
                    osoite.Postitmp = tbTmp.Text;
                    tyontekija.osoite = osoite;
                    Tyotiedot tyotiedot = new Tyotiedot();
                    tyotiedot.Nimike = tbNimike.Text;
                    tyotiedot.Yksikko = tbYksikko.Text;
                    tyotiedot.TyoAlkoi = dtpAlkoi.Value;
                    if (cbVoimassa.Checked)
                    {

                        tyotiedot.Loppunut = false;
                    }
                    else
                    {
                        tyotiedot.Loppunut = true;
                        tyotiedot.TyoLoppui = dtpLoppui.Value;
                    }
                    tyontekija.Tiedot = tyotiedot;


                    if (muokkaus == false)
                    {
                        palkattava.Add(tyontekija);
                        toiminto = "Lisättiin työntekijä";

                    }
                    else
                    {
                        palkattava[Rivivalinta] = tyontekija;
                        toiminto = "Muokkaukset tallennettiin";
                    }
                    TallennaTiedostoon(palkattava, dir);
                    LisaaNakymaan(dir);
                    Tallennatoiminto(toiminto);
                    tcValilehdet.SelectedTab = tpTyotekijat;
                }

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }
        /* toiminto menuvalikon "lisää nappia" ja työntekijä välehden "Lisäänappia varten varten.
        * toiminto tyhjentää lomakkeen tekstikentät määrittää muokkauksen pois ja "lisää työntekijä" valikon aktiiviseksi.
        */
        private void tsLisaa_Click(object sender, EventArgs e)
        {
            tyhjennaKentat();
            muokkaus = false;
            tcValilehdet.SelectedTab = tpLisaa;
        }
        /* Sovelluksen alkuperäisessä tehtävän annossa tätä ei pyydetty mutta tein tämän
        * harjoituksen vuoksi. Toiminnolla voidaan tuoda erillisestä tiedostosta työntekijälista sovellukseen.
        */
        private void tsTuo_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult result = ofAvaa.ShowDialog();
                if (result != DialogResult.Cancel)
                {
                    palkattava = HaeTiedostosta(palkattava, ofAvaa.FileName);
                     LisaaNakymaan(ofAvaa.FileName);
                    toiminto = "Tiedosto " + ofAvaa.FileName + " avattiin";
                    Tallennatoiminto(toiminto);
                    tcValilehdet.SelectedTab = tpTyotekijat;
                }
                else
                    return;

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message, "Tiedostoa ei voitu tuoda.");
            }
        }
        /* Toiminnolla sama tilanne kuin aikasemmalla. Toiminnon avulla voidaan työntekijä
         * lista tallentaa haluttuun paikkaan.
         */
        private void tsVie_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult result = sfTallenna.ShowDialog();
                if (result != DialogResult.Cancel)
                {
                    string uusidir = sfTallenna.FileName + ".json";
                    TallennaTiedostoon(palkattava, uusidir);
                }

                else
                    return;

                toiminto = "Tiedosto " + sfTallenna.FileName + " tallennettiin";
                Tallennatoiminto(toiminto);
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message, "Virhe Avaamisessa!");
            }
        }

        /* Toiminto tuo muokattavan data table rivin tiedot työntekijä lomakkeelle.
         * Toiminto asettaa muokkaus arvon oikeaksi jotta tiedot tallentuvat takaisin samalle
         * paikalle eikä uuteen riviin
         */
        private void btnMuokkaa_Click(object sender, EventArgs e)
        {
            try
            {
                Tyontekija valittu = palkattava[Rivivalinta];
                dtpAlkoi.MaxDate = DateTime.Today.AddHours(24.00);
                dtpLoppui.MaxDate = DateTime.Today.AddHours(24.00);



                tbEtunimi.Text = valittu.Etunimi;
                tbKutsumanimi.Text = valittu.Kutsumanimi;
                tbSukunimi.Text = valittu.Sukunimi;
                tbHetu.Text = valittu.Hetu;
                tbOsoite.Text = valittu.OsoiteKatu;
                tbPostinro.Text = valittu.OsoiteNumero;
                tbTmp.Text = valittu.OsoiteTmp;
                tbNimike.Text = valittu.tyoNimike;
                tbYksikko.Text = valittu.tyoyksikko;
                dtpAlkoi.Value = valittu.TyotAlkoi;
                dtpLoppui.MinDate = dtpAlkoi.Value;
                if (valittu.Loppunut == "-")
                {
                    dtpLoppui.Value = DateTime.Now;
                    cbVoimassa.Checked = true;
                }
                else
                {
                    dtpLoppui.Value = valittu.TyotLoppui;
                    cbVoimassa.Checked = false;
                }
                
                
                muokkaus = true;
                toiminto = "Työntekijän muokkaus";
                Tallennatoiminto(toiminto);
                tcValilehdet.SelectedTab = tpLisaa;
            }
            catch (Exception Ex)
            {

                MessageBox.Show(Ex.Message);
            }
        }

        /*Toiminto kysyy käyttäjältä varmistuksen tietojen poistoon. Käyttäjän valitessa kyllä
         * toiminto poistaa tiedot oikeasta kohtaa listaa ja näyttää uudelleen tiedot datatablessa
         */
        private void Poista_Click(object sender, EventArgs e)
        {
            if (dgvLista.CurrentRow != null)
            {


                Rivivalinta = dgvLista.CurrentRow.Index;
                if (Rivivalinta >= 0)
                {


                    DialogResult result = MessageBox.Show("Oletko varma että haluat poistaa työntekijän?", "Poistetaanko?", MessageBoxButtons.OKCancel);
                    if (result == DialogResult.OK)
                    {
                        palkattava.RemoveAt(Rivivalinta);

                        TallennaTiedostoon(palkattava, dir);
                        LisaaNakymaan(dir);
                        toiminto = "Tiedosto poistettiin";
                        Tallennatoiminto(toiminto);
                    }
                    else
                        return;
                }
            }
        }
        /* tallentaa valintarivin luvun jotta muokkaus ja poisto toimivat
         * oikealla rivillä.           
        */
        private void dgvLista_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvLista.CurrentRow != null)
                Rivivalinta = dgvLista.CurrentRow.Index;
        }
        /*Sovellus antoi valita lisää välilehteä painamalla lomakkeen ilman tyhjennystä.
         * Toiminnossa huomioitu muokkaustila. Muokkaus tila mahdollistaa välilehtien vaihtamisen ilman että 
         * sovellus tyhjentää tietoja lomakkeen kentistä.
         */
        private void tcValilehdet_Selecting(object sender, TabControlCancelEventArgs e)
        {
            if (!muokkaus)
            {
            tyhjennaKentat();
            }
                
            //muokkaus = false;
        }
        // Toiminto pakottaa sulkemaan sovelluksen vaikka valdiointia ei olisi tehty
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = false;
        }
        // Muuttaa työsuhteen loppumispäivämäärän valintamahdollisuudet alkamispäivämäärän mukaan
        private void dtpAlkoi_ValueChanged(object sender, EventArgs e)
        {
            dtpLoppui.MinDate = dtpAlkoi.Value;
        }

        // Loki katselu napin toiminto. Avaa uudelle formille loki tiedot.
        private void tsKatsolokia_Click(object sender, EventArgs e)
        {
            string dir = @"c:/TempCrap/log.txt";
            Logi_tiedot formi = new Logi_tiedot(dir);
            formi.ShowDialog();
        }
    }
}
