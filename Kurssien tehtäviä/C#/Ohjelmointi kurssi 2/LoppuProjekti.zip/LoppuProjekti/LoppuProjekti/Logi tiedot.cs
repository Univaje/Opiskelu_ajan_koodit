﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoppuProjekti
{
    public partial class Logi_tiedot : Form
    {
        public Logi_tiedot()
        {
            InitializeComponent();
        }
        public Logi_tiedot(string dir)
        {
            InitializeComponent();
            try
            {
                StreamReader reader = new StreamReader(dir);
                {
                    
                    tbLokitiedot.Text = reader.ReadToEnd();

                }
                // readeri on suljettava kokonaan tai log.txt jää tämän käyttöön ja aiheuttaa ongelmia pääformilla.
                reader.Dispose();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }
        /*Huolehditaan ettei tekstiä voi poistaa vahingossa loki näkymästä.
         */
        private void tbLokitiedot_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }
    }
}
