﻿namespace LoppuProjekti
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.dtpLoppui = new System.Windows.Forms.DateTimePicker();
            this.tcValilehdet = new System.Windows.Forms.TabControl();
            this.tpTyotekijat = new System.Windows.Forms.TabPage();
            this.btnPoista = new System.Windows.Forms.Button();
            this.btnMuokkaa = new System.Windows.Forms.Button();
            this.btnLisaa2 = new System.Windows.Forms.Button();
            this.dgvLista = new System.Windows.Forms.DataGridView();
            this.tpLisaa = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnLisaa = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.cbVoimassa = new System.Windows.Forms.CheckBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.dtpAlkoi = new System.Windows.Forms.DateTimePicker();
            this.tbYksikko = new System.Windows.Forms.TextBox();
            this.tbNimike = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tbTmp = new System.Windows.Forms.TextBox();
            this.tbPostinro = new System.Windows.Forms.TextBox();
            this.tbOsoite = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tbHetu = new System.Windows.Forms.TextBox();
            this.tbKutsumanimi = new System.Windows.Forms.TextBox();
            this.tbSukunimi = new System.Windows.Forms.TextBox();
            this.tbEtunimi = new System.Windows.Forms.TextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsLisaa = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMuokkaa = new System.Windows.Forms.ToolStripMenuItem();
            this.tsPoista = new System.Windows.Forms.ToolStripMenuItem();
            this.tuoVieToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsTuo = new System.Windows.Forms.ToolStripMenuItem();
            this.tsVie = new System.Windows.Forms.ToolStripMenuItem();
            this.katsoLokiaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.epVirhe = new System.Windows.Forms.ErrorProvider(this.components);
            this.sfTallenna = new System.Windows.Forms.SaveFileDialog();
            this.ofAvaa = new System.Windows.Forms.OpenFileDialog();
            this.tcValilehdet.SuspendLayout();
            this.tpTyotekijat.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLista)).BeginInit();
            this.tpLisaa.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.epVirhe)).BeginInit();
            this.SuspendLayout();
            // 
            // dtpLoppui
            // 
            this.dtpLoppui.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpLoppui.Location = new System.Drawing.Point(482, 175);
            this.dtpLoppui.Name = "dtpLoppui";
            this.dtpLoppui.Size = new System.Drawing.Size(323, 30);
            this.dtpLoppui.TabIndex = 11;
            this.dtpLoppui.Visible = false;
            // 
            // tcValilehdet
            // 
            this.tcValilehdet.Controls.Add(this.tpTyotekijat);
            this.tcValilehdet.Controls.Add(this.tpLisaa);
            this.tcValilehdet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tcValilehdet.Location = new System.Drawing.Point(0, 28);
            this.tcValilehdet.Name = "tcValilehdet";
            this.tcValilehdet.SelectedIndex = 0;
            this.tcValilehdet.Size = new System.Drawing.Size(1557, 755);
            this.tcValilehdet.TabIndex = 0;
            this.tcValilehdet.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tcValilehdet_Selecting);
            // 
            // tpTyotekijat
            // 
            this.tpTyotekijat.Controls.Add(this.btnPoista);
            this.tpTyotekijat.Controls.Add(this.btnMuokkaa);
            this.tpTyotekijat.Controls.Add(this.btnLisaa2);
            this.tpTyotekijat.Controls.Add(this.dgvLista);
            this.tpTyotekijat.Location = new System.Drawing.Point(4, 25);
            this.tpTyotekijat.Name = "tpTyotekijat";
            this.tpTyotekijat.Padding = new System.Windows.Forms.Padding(3);
            this.tpTyotekijat.Size = new System.Drawing.Size(1549, 726);
            this.tpTyotekijat.TabIndex = 1;
            this.tpTyotekijat.Text = "Työntekijät";
            this.tpTyotekijat.UseVisualStyleBackColor = true;
            // 
            // btnPoista
            // 
            this.btnPoista.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPoista.Location = new System.Drawing.Point(1405, 648);
            this.btnPoista.Name = "btnPoista";
            this.btnPoista.Size = new System.Drawing.Size(125, 47);
            this.btnPoista.TabIndex = 3;
            this.btnPoista.Text = "Poista";
            this.btnPoista.UseVisualStyleBackColor = true;
            this.btnPoista.Click += new System.EventHandler(this.Poista_Click);
            // 
            // btnMuokkaa
            // 
            this.btnMuokkaa.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnMuokkaa.Location = new System.Drawing.Point(704, 648);
            this.btnMuokkaa.Name = "btnMuokkaa";
            this.btnMuokkaa.Size = new System.Drawing.Size(125, 47);
            this.btnMuokkaa.TabIndex = 2;
            this.btnMuokkaa.Text = "Muokkaa";
            this.btnMuokkaa.UseVisualStyleBackColor = true;
            this.btnMuokkaa.Click += new System.EventHandler(this.btnMuokkaa_Click);
            // 
            // btnLisaa2
            // 
            this.btnLisaa2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnLisaa2.Location = new System.Drawing.Point(22, 648);
            this.btnLisaa2.Name = "btnLisaa2";
            this.btnLisaa2.Size = new System.Drawing.Size(125, 47);
            this.btnLisaa2.TabIndex = 1;
            this.btnLisaa2.Text = "Lisää";
            this.btnLisaa2.UseVisualStyleBackColor = true;
            this.btnLisaa2.Click += new System.EventHandler(this.tsLisaa_Click);
            // 
            // dgvLista
            // 
            this.dgvLista.AllowUserToAddRows = false;
            this.dgvLista.AllowUserToDeleteRows = false;
            this.dgvLista.AllowUserToOrderColumns = true;
            this.dgvLista.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvLista.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvLista.Location = new System.Drawing.Point(65, 0);
            this.dgvLista.MultiSelect = false;
            this.dgvLista.Name = "dgvLista";
            this.dgvLista.RowHeadersWidth = 51;
            this.dgvLista.RowTemplate.Height = 24;
            this.dgvLista.RowTemplate.ReadOnly = true;
            this.dgvLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvLista.Size = new System.Drawing.Size(1543, 611);
            this.dgvLista.TabIndex = 0;
            this.dgvLista.SelectionChanged += new System.EventHandler(this.dgvLista_SelectionChanged);
            // 
            // tpLisaa
            // 
            this.tpLisaa.Controls.Add(this.groupBox4);
            this.tpLisaa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tpLisaa.Location = new System.Drawing.Point(4, 25);
            this.tpLisaa.Name = "tpLisaa";
            this.tpLisaa.Padding = new System.Windows.Forms.Padding(3);
            this.tpLisaa.Size = new System.Drawing.Size(1549, 726);
            this.tpLisaa.TabIndex = 0;
            this.tpLisaa.Text = "Lisää Työntekijä";
            this.tpLisaa.ToolTipText = "Työntekijän tietojen muokkaus";
            this.tpLisaa.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btnLisaa);
            this.groupBox4.Controls.Add(this.groupBox3);
            this.groupBox4.Controls.Add(this.groupBox2);
            this.groupBox4.Controls.Add(this.groupBox1);
            this.groupBox4.Location = new System.Drawing.Point(355, 9);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(939, 707);
            this.groupBox4.TabIndex = 16;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "  ";
            // 
            // btnLisaa
            // 
            this.btnLisaa.Location = new System.Drawing.Point(259, 634);
            this.btnLisaa.Name = "btnLisaa";
            this.btnLisaa.Size = new System.Drawing.Size(373, 44);
            this.btnLisaa.TabIndex = 15;
            this.btnLisaa.Text = "Tallenna Työntekijä";
            this.btnLisaa.UseVisualStyleBackColor = true;
            this.btnLisaa.Click += new System.EventHandler(this.btnTallenna_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.cbVoimassa);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.dtpLoppui);
            this.groupBox3.Controls.Add(this.dtpAlkoi);
            this.groupBox3.Controls.Add(this.tbYksikko);
            this.groupBox3.Controls.Add(this.tbNimike);
            this.groupBox3.Location = new System.Drawing.Point(23, 383);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(870, 233);
            this.groupBox3.TabIndex = 14;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Työsuhde Tiedot:";
            // 
            // cbVoimassa
            // 
            this.cbVoimassa.AutoSize = true;
            this.cbVoimassa.Checked = true;
            this.cbVoimassa.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbVoimassa.Location = new System.Drawing.Point(459, 115);
            this.cbVoimassa.Name = "cbVoimassa";
            this.cbVoimassa.Size = new System.Drawing.Size(277, 29);
            this.cbVoimassa.TabIndex = 16;
            this.cbVoimassa.Text = "Toistaiseksi voimassa oleva";
            this.cbVoimassa.UseVisualStyleBackColor = true;
            this.cbVoimassa.CheckedChanged += new System.EventHandler(this.cb_Voimassa_CheckedChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(477, 147);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(170, 25);
            this.label11.TabIndex = 15;
            this.label11.Text = "Työsuhde Päättyi:";
            this.label11.Visible = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(32, 147);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(154, 25);
            this.label10.TabIndex = 14;
            this.label10.Text = "Työsuhde Alkoi:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(477, 26);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(80, 25);
            this.label9.TabIndex = 13;
            this.label9.Text = "Yksikkö";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(32, 26);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(71, 25);
            this.label8.TabIndex = 12;
            this.label8.Text = "Nimike";
            // 
            // dtpAlkoi
            // 
            this.dtpAlkoi.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpAlkoi.Location = new System.Drawing.Point(37, 175);
            this.dtpAlkoi.Name = "dtpAlkoi";
            this.dtpAlkoi.Size = new System.Drawing.Size(300, 30);
            this.dtpAlkoi.TabIndex = 10;
            this.dtpAlkoi.Value = new System.DateTime(2020, 12, 11, 0, 0, 0, 0);
            this.dtpAlkoi.ValueChanged += new System.EventHandler(this.dtpAlkoi_ValueChanged);
            // 
            // tbYksikko
            // 
            this.tbYksikko.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbYksikko.Location = new System.Drawing.Point(482, 59);
            this.tbYksikko.Name = "tbYksikko";
            this.tbYksikko.Size = new System.Drawing.Size(323, 30);
            this.tbYksikko.TabIndex = 9;
            this.tbYksikko.Validating += new System.ComponentModel.CancelEventHandler(this.Validoikentta);
            this.tbYksikko.Validated += new System.EventHandler(this.Validoitukentta);
            // 
            // tbNimike
            // 
            this.tbNimike.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbNimike.Location = new System.Drawing.Point(37, 59);
            this.tbNimike.Name = "tbNimike";
            this.tbNimike.Size = new System.Drawing.Size(300, 30);
            this.tbNimike.TabIndex = 8;
            this.tbNimike.Validating += new System.ComponentModel.CancelEventHandler(this.Validoikentta);
            this.tbNimike.Validated += new System.EventHandler(this.Validoitukentta);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.tbTmp);
            this.groupBox2.Controls.Add(this.tbPostinro);
            this.groupBox2.Controls.Add(this.tbOsoite);
            this.groupBox2.Location = new System.Drawing.Point(23, 226);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(870, 139);
            this.groupBox2.TabIndex = 13;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Osoite Tiedot:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(510, 46);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(152, 25);
            this.label7.TabIndex = 11;
            this.label7.Text = "Postitoimipaikka";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(291, 46);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(121, 25);
            this.label6.TabIndex = 10;
            this.label6.Text = "Postinumero";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(48, 46);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(105, 25);
            this.label5.TabIndex = 9;
            this.label5.Text = "Katuosoite";
            // 
            // tbTmp
            // 
            this.tbTmp.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbTmp.Location = new System.Drawing.Point(515, 74);
            this.tbTmp.Name = "tbTmp";
            this.tbTmp.Size = new System.Drawing.Size(290, 30);
            this.tbTmp.TabIndex = 7;
            this.tbTmp.Validating += new System.ComponentModel.CancelEventHandler(this.Validoikentta);
            this.tbTmp.Validated += new System.EventHandler(this.Validoitukentta);
            // 
            // tbPostinro
            // 
            this.tbPostinro.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbPostinro.Location = new System.Drawing.Point(296, 74);
            this.tbPostinro.Name = "tbPostinro";
            this.tbPostinro.Size = new System.Drawing.Size(175, 30);
            this.tbPostinro.TabIndex = 6;
            this.tbPostinro.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbPostinro_KeyPress);
            this.tbPostinro.KeyUp += new System.Windows.Forms.KeyEventHandler(this.tbPostinro_KeyPress);
            this.tbPostinro.Validating += new System.ComponentModel.CancelEventHandler(this.Validoikentta);
            this.tbPostinro.Validated += new System.EventHandler(this.Validoitukentta);
            // 
            // tbOsoite
            // 
            this.tbOsoite.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOsoite.Location = new System.Drawing.Point(47, 74);
            this.tbOsoite.Name = "tbOsoite";
            this.tbOsoite.Size = new System.Drawing.Size(208, 30);
            this.tbOsoite.TabIndex = 5;
            this.tbOsoite.Validating += new System.ComponentModel.CancelEventHandler(this.Validoikentta);
            this.tbOsoite.Validated += new System.EventHandler(this.Validoitukentta);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.tbHetu);
            this.groupBox1.Controls.Add(this.tbKutsumanimi);
            this.groupBox1.Controls.Add(this.tbSukunimi);
            this.groupBox1.Controls.Add(this.tbEtunimi);
            this.groupBox1.Location = new System.Drawing.Point(23, 15);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(870, 205);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Henkilö Tiedot:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(32, 120);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(136, 25);
            this.label4.TabIndex = 8;
            this.label4.Text = "Henkilötunnus";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(577, 36);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 25);
            this.label3.TabIndex = 7;
            this.label3.Text = "Sukunimi";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(301, 36);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(125, 25);
            this.label2.TabIndex = 6;
            this.label2.Text = "Kutsumanimi";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(32, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 25);
            this.label1.TabIndex = 5;
            this.label1.Text = "Etunimi";
            // 
            // tbHetu
            // 
            this.tbHetu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHetu.Location = new System.Drawing.Point(37, 148);
            this.tbHetu.Name = "tbHetu";
            this.tbHetu.Size = new System.Drawing.Size(156, 30);
            this.tbHetu.TabIndex = 4;
            this.tbHetu.Validating += new System.ComponentModel.CancelEventHandler(this.Validoikentta);
            this.tbHetu.Validated += new System.EventHandler(this.Validoitukentta);
            // 
            // tbKutsumanimi
            // 
            this.tbKutsumanimi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbKutsumanimi.Location = new System.Drawing.Point(306, 64);
            this.tbKutsumanimi.Name = "tbKutsumanimi";
            this.tbKutsumanimi.Size = new System.Drawing.Size(225, 30);
            this.tbKutsumanimi.TabIndex = 2;
            this.tbKutsumanimi.Validating += new System.ComponentModel.CancelEventHandler(this.Validoikentta);
            this.tbKutsumanimi.Validated += new System.EventHandler(this.Validoitukentta);
            // 
            // tbSukunimi
            // 
            this.tbSukunimi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbSukunimi.Location = new System.Drawing.Point(582, 64);
            this.tbSukunimi.Name = "tbSukunimi";
            this.tbSukunimi.Size = new System.Drawing.Size(223, 30);
            this.tbSukunimi.TabIndex = 3;
            this.tbSukunimi.Validating += new System.ComponentModel.CancelEventHandler(this.Validoikentta);
            this.tbSukunimi.Validated += new System.EventHandler(this.Validoitukentta);
            // 
            // tbEtunimi
            // 
            this.tbEtunimi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbEtunimi.Location = new System.Drawing.Point(37, 64);
            this.tbEtunimi.Name = "tbEtunimi";
            this.tbEtunimi.Size = new System.Drawing.Size(224, 30);
            this.tbEtunimi.TabIndex = 1;
            this.tbEtunimi.Validating += new System.ComponentModel.CancelEventHandler(this.Validoikentta);
            this.tbEtunimi.Validated += new System.EventHandler(this.Validoitukentta);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.tuoVieToolStripMenuItem,
            this.katsoLokiaToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1557, 28);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsLisaa,
            this.tsMuokkaa,
            this.tsPoista});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.T)));
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(82, 24);
            this.fileToolStripMenuItem.Text = "&Toiminto";
            // 
            // tsLisaa
            // 
            this.tsLisaa.Image = ((System.Drawing.Image)(resources.GetObject("tsLisaa.Image")));
            this.tsLisaa.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsLisaa.Name = "tsLisaa";
            this.tsLisaa.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.L)));
            this.tsLisaa.Size = new System.Drawing.Size(293, 26);
            this.tsLisaa.Text = "Lisää Työntekijä";
            this.tsLisaa.Click += new System.EventHandler(this.tsLisaa_Click);
            // 
            // tsMuokkaa
            // 
            this.tsMuokkaa.Name = "tsMuokkaa";
            this.tsMuokkaa.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.M)));
            this.tsMuokkaa.Size = new System.Drawing.Size(293, 26);
            this.tsMuokkaa.Text = "Muokkkaa Työntekijää";
            this.tsMuokkaa.Click += new System.EventHandler(this.btnMuokkaa_Click);
            // 
            // tsPoista
            // 
            this.tsPoista.Name = "tsPoista";
            this.tsPoista.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.P)));
            this.tsPoista.Size = new System.Drawing.Size(293, 26);
            this.tsPoista.Text = "Poista Työntekijä";
            this.tsPoista.Click += new System.EventHandler(this.Poista_Click);
            // 
            // tuoVieToolStripMenuItem
            // 
            this.tuoVieToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsTuo,
            this.tsVie});
            this.tuoVieToolStripMenuItem.Name = "tuoVieToolStripMenuItem";
            this.tuoVieToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.V)));
            this.tuoVieToolStripMenuItem.Size = new System.Drawing.Size(83, 24);
            this.tuoVieToolStripMenuItem.Text = "Tuo / &Vie";
            // 
            // tsTuo
            // 
            this.tsTuo.Name = "tsTuo";
            this.tsTuo.Size = new System.Drawing.Size(193, 26);
            this.tsTuo.Text = "Tuo Työntekijät";
            this.tsTuo.Click += new System.EventHandler(this.tsTuo_Click);
            // 
            // tsVie
            // 
            this.tsVie.Name = "tsVie";
            this.tsVie.Size = new System.Drawing.Size(193, 26);
            this.tsVie.Text = "Vie Työntekijät";
            this.tsVie.Click += new System.EventHandler(this.tsVie_Click);
            // 
            // katsoLokiaToolStripMenuItem
            // 
            this.katsoLokiaToolStripMenuItem.Name = "katsoLokiaToolStripMenuItem";
            this.katsoLokiaToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.L)));
            this.katsoLokiaToolStripMenuItem.Size = new System.Drawing.Size(99, 24);
            this.katsoLokiaToolStripMenuItem.Text = "Katso &Lokia";
            this.katsoLokiaToolStripMenuItem.Click += new System.EventHandler(this.tsKatsolokia_Click);
            // 
            // epVirhe
            // 
            this.epVirhe.ContainerControl = this;
            // 
            // ofAvaa
            // 
            this.ofAvaa.FileName = "openFileDialog1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1557, 783);
            this.Controls.Add(this.tcValilehdet);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Työntekijöiden Ylläpito";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.tcValilehdet.ResumeLayout(false);
            this.tpTyotekijat.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvLista)).EndInit();
            this.tpLisaa.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.epVirhe)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tcValilehdet;
        private System.Windows.Forms.TabPage tpLisaa;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.DateTimePicker dtpAlkoi;
        private System.Windows.Forms.TextBox tbYksikko;
        private System.Windows.Forms.TextBox tbNimike;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox tbTmp;
        private System.Windows.Forms.TextBox tbPostinro;
        private System.Windows.Forms.TextBox tbOsoite;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox tbHetu;
        private System.Windows.Forms.TextBox tbKutsumanimi;
        private System.Windows.Forms.TextBox tbSukunimi;
        private System.Windows.Forms.TextBox tbEtunimi;
        private System.Windows.Forms.TabPage tpTyotekijat;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tsLisaa;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox cbVoimassa;
        private System.Windows.Forms.DataGridView dgvLista;
        private System.Windows.Forms.DateTimePicker dtpLoppui;
        private System.Windows.Forms.ErrorProvider epVirhe;
        private System.Windows.Forms.Button btnLisaa;
        private System.Windows.Forms.ToolStripMenuItem tsMuokkaa;
        private System.Windows.Forms.ToolStripMenuItem tsPoista;
        private System.Windows.Forms.ToolStripMenuItem tuoVieToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tsTuo;
        private System.Windows.Forms.ToolStripMenuItem tsVie;
        private System.Windows.Forms.Button btnPoista;
        private System.Windows.Forms.Button btnMuokkaa;
        private System.Windows.Forms.Button btnLisaa2;
        private System.Windows.Forms.SaveFileDialog sfTallenna;
        private System.Windows.Forms.OpenFileDialog ofAvaa;
        private System.Windows.Forms.ToolStripMenuItem katsoLokiaToolStripMenuItem;
        private System.Windows.Forms.GroupBox groupBox4;
    }
}

