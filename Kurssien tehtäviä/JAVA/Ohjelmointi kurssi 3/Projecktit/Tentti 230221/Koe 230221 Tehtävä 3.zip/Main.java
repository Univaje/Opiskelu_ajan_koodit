package com.company;

import com.company.Tehtava3.Asunto;
import com.company.Tehtava3.AsuntoUtils;
import com.company.Tehtava3.Henkilo;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	/*
	* Taloyhtiön As oy Mustikkarinne puheenjohtajalla on ollut kovin kankea sovellus, jossa järjestelmään on syötetty
	* asunnoissa asuvat henkilöt. Se on näyttänyt jotakuinkin seuraavalta

        Anna asunnon numero (0 = Lopettaa syötön): A1
        Anna asujan etunimi: Ami
        Anna asujan sukunimi: Asujainen
        Anna asujan ikä kuluvana vuonna: 23
        Anna asunnon numero (0 = Lopettaa syötön): A1
        Anna asujan etunimi: Anu
        Anna asujan sukunimi: Asujainen
        Annaa asujan ikä kuluvana vuonna: 31
        Anna asunnon numero (0 = Lopettaa syötön): B12
        Anna asujan etunimi: Aimo
        Anna asujan sukunimi: Korhonen
        Anna asujan ikä kuluvana vuonna: 55
        Anna asunnon numero (0 = Lopettaa syötön): 0



        Asujat:
        Ami Asuja, Asunto: A1, Ikä: 23
        Anu Asuja, Asunto: A1, Ikä: 31
        Aimo Korhonen, Asunto: B12, Ikä: 55



        1. vaihe :Tee Java-ohjelma, jossa on sama toiminnallisuus. Käytä luokkia ja sopivia tietorakenteita
        * ja koodaa pääohjelma. Huolehdi luokan (luokkien) perusmetodien koodauksesta. Syötteiden järkevyys-
        * ja tyyppitarkistuksia ei tarvitse toteuttaa. (luokka/luokat 3p, pääohjelma 2 p)
        */

        //Ohjelman sisäisiä muuttujia
        // Testi dataa
        ArrayList<Asunto> asukkaat = new ArrayList<>();
        Henkilo h1 = new Henkilo("Ami","Asujainen",23);
        Henkilo h2 = new Henkilo("Anu","Asujainen",31);
        Henkilo h3 = new Henkilo("Aimo","Korhonen",55);
        Asunto a1 = new Asunto(h1,"A1");
        Asunto a2 = new Asunto(h2,"A2");
        Asunto a3 = new Asunto(h3,"B12");
        asukkaat.add(a1);
        asukkaat.add(a2);
        asukkaat.add(a3);
        Scanner input = new Scanner(System.in);
        String syote, asunnonNumero = "";
        Henkilo asuja;
        Asunto asunto;

        // Loopataan asiakkaan lisäämistä
        while (true){
            System.out.print("Syötetäänkö uusi asukas? (k/e)");
            syote = input.nextLine();
            if (syote.equals("k")){
                //Luodaan uudet asukas ja asunto oliot
                asuja = new Henkilo();
                asunto = new Asunto();
                //Täytetään asunto tiedot
                asunto.kysyAsunnonTiedot(asuja);
                ///////////////////////////////
                     //Testausta varten//
                System.out.println(asuja);
                System.out.println(asunto);
                ///////////////////////////////
                //Lisätään asunto listaan
                asukkaat.add(asunto);

            }
            // poistutaan loopistä syöttämällä e
            else if (syote.equals("e")){
                break;
            }
            else
                // ei hyvväksytä muita syötteitä
                System.out.println("Virheellinen syöte!");
        }
        // Tulostetaan asukkaat
        for (Asunto a: asukkaat ) {
            System.out.println(a);
        }
        //ASuntoutils luokan testaus
        System.out.print("Etsi asiakas syöttämällä asunnon numero:");
        asunnonNumero = input.nextLine();
        AsuntoUtils.palautaAsujat(asunnonNumero,asukkaat);

        // keskiIan testaus
        System.out.print("Asukkaiden keski ikä on: ");
        System.out.println(AsuntoUtils.KeskiIka(asukkaat));
    }
}
