package com.company.Tehtava1;

/*
Creator: Sam
Date: 21.02.2021
Version: 0.1
Description:
    - Tee luokka PrintDiamond tulostaa ajettaessa salmiakkikuvion (luokalla on siis yksi metodi, esim. print):
       *
      ***
     *****
    *******
     *****
      ***
       *
*/
public class PrintDiamond {

    //Jäsenmuuttujat


    //Constructorit


    //Getterit ja Setterit


    //Metodit
    public void PrintDiamond(){
        System.out.println("   *   ");
        System.out.println("  ***  ");
        System.out.println(" ***** ");
        System.out.println("*******");
        System.out.println(" ***** ");
        System.out.println("  ***  ");
        System.out.println("   *   ");
    }

}
