package com.company;

import java.util.Date;

/*
Creator: Sam
Date: 23.02.2021
Version: 0.1
Description:

*/      public class Tilaus{


        private int tilausnumero;
        private Date tilauspvm;

        public Tilaus( ) {
        }

        public Tilaus(int tilausnumero)
        {
            this.tilausnumero= tilausnumero;
        }


        public int getTilausnumero()
        {
            return tilausnumero;
        }
}



    //Jäsenmuuttujat


    //Constructorit


    //Getterit ja Setterit


    //Metodit


