package com.company;

import com.company.Tehtava3.Asunto;
import com.company.Tehtava3.AsuntoUtils;
import com.company.Tehtava3.Henkilo;
import com.company.Tehtava4.Juhlatakki;
import com.company.Tehtava4.Takki;
import com.company.Tehtava4.Ulkoilutakki;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

/*
        Oheinen varsin suppean koodi sisältävä määrittelee luokan Takki olion.
        Tee luokalle aliluokat Ulkoilutakki ja Juhlatakki.

            public class Takki {
            String vari;
            String koko;

            public Takki() {
            }
        }
         Tee pääohjelma, joka käsittelee luokan Takki ja sen aliluokkien olioita taulukossa (tai ArrayList-rakenteessa).
         Lisää taulukkoon vähintään 2 oliota luokista Ulkoilutakki ja Juhlatakki.
         Ei siis tarvitse koodata käyttöliittymää vaan riittää, että "kovakoodaat" takit listaan.
         Ohjelma tulostaa taulukon olioiden tiedot luettavassa muodossa näkyville.

        (Arvostelu: Aliluokat (3 p), pääohjelma  (2 p) (yht 5 p)



*/
        //Luodaan Arraylist objekteille ja lisätään siihen objekteja
        ArrayList<Object> Takit = new ArrayList<>();
        Takki T1 = new Ulkoilutakki("Sininen","M",10000,4950);
        Takki T2 = new Juhlatakki("Punainen","L","Silkki","Pitsi");
        Ulkoilutakki T3 = new Ulkoilutakki("Keltainen","S",3000,1);
        Juhlatakki T4 = new Juhlatakki("Musta","XL","Villa","Kuvioton");
        Ulkoilutakki T5 = new Ulkoilutakki("Oranssi","XXXXL",99,5001);
        Juhlatakki T6 = new Juhlatakki("Violetti","M","Vakosametti","Ruutu");
        Ulkoilutakki T7 = new Ulkoilutakki("Purppura","L",3001,-1);
        Juhlatakki T8 = new Juhlatakki("Ruskea","S","Puuvilla","Liituraita");
        Takit.add(T1);
        Takit.add(T2);
        Takit.add(T3);
        Takit.add(T4);
        Takit.add(T5);
        Takit.add(T6);
        Takit.add(T7);
        Takit.add(T8);
        // käydään objektit instance of:lla ja muutetaan jokainen oikeanlaiseksi tulostusta varten
        for (Object O :Takit) {
            if (O instanceof Ulkoilutakki) {
                Ulkoilutakki UT = (Ulkoilutakki) O;
                System.out.println(UT);
            }
                if (O instanceof Juhlatakki) {
                    Juhlatakki JT = (Juhlatakki) O;
                    System.out.println(JT);
                }

        }
    }
}
