
package com.company;

import com.company.Tehtava3.Asunto;
import com.company.Tehtava3.AsuntoUtils;
import com.company.Tehtava3.Henkilo;
import com.company.Tehtava4.Juhlatakki;
import com.company.Tehtava4.Takki;
import com.company.Tehtava4.Ulkoilutakki;
import com.company.Tehtava5.HaminalahdenMetsastysseura;
import com.company.Tehtava5.Jasen;
import com.company.Tehtava5.TurmiolanEra;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

/*
        Pohjois-Savon Riistanhoitoyhdistys on päättänyt parantaa yleistä tiedotustaan alueen metsästysseurojen
        jäsenille. Niinpä se tarvitsee tiedot kaikista eri metsästysseurojen jäsenistä. Ohjelmistoon tarvitaan
        siis laajennus, jotta se voi hakea jäsentiedot eri seurojen käyttämistä järjestelmistäOhjelmistossa
        on laajennus, joilla pelaajien tietoja voidaan noutaa eri urheiluseurojen järjestelmistä. Tietojen
        nouto toteutetaan käyttäen rajapintaa, jossa on yksi metodi:

                          public ArrayList<Jasen> getJasenTiedot();

        Rajapintaa testataan seuraaville seuroilla eli TurmiolanErä ja HaminalahdenMetsästysseura.
        Niille tehdään siis erilliset luokat.  Molempien seurojen luokat, jotka toteuttavat eo rajapintaa,
        palauttavat testimielessä esim kolme jäsenen tiedot. Kovakoodaat jäsenet ko metodiin.

        Jasen-luokkaa (liitteenä) tulee lisäksi  laajentaa niin, että se perii abstraktin luokan JäsenBase,
        jonka toteutat laajennuksen yhteydessä. JasenBase-luokassa on  jäsenseura (String) ja vakuutusnro (int)
        sekä abstrakti metodi tulostaJäsenTiedot. Toteuta abstrakti metodi oikeassa paikassa, niin, että se
        tulostaa jäsenen tiedot oikein.

        Tee ohjelma, joka hakee jäsenet molemmista seuroista sekä tulostaa jäsenten kaikki tiedot ruudulle.
        Pitäisi tulostua siis kuuden eri jäsenen tiedot. Jäsenten tiedot voit itse keksiä rajapinnat toteuttavien
        luokkien toteutukseen.

        Jasen.java:
        public class Jasen{
                             private String etunimi;
                             private String sukunimi;
                             private String email;
         }


        Arviointi: Rajapinta 1 p, Toteuttavat (seurojen) luokat 2 p,
        Jasen-luokan muunnokset 1p, JasenBase- luokka 1 p, Pääohjelma 2 p, Yht  7p,

       //////////////////////////////////////
       //Harvinaisen sekava tehtäväksianto!//
       //////////////////////////////////////
         */


        // Luodaan lista johon haetaan Metsästysseurojen tiedot
        ArrayList<Jasen> Tietokanta= new ArrayList<>();
        // luodaan metsästys seuraoliot
        TurmiolanEra T1 = new TurmiolanEra();
        HaminalahdenMetsastysseura H1 = new HaminalahdenMetsastysseura();
        //Käytetään rajapinnan metodia ja lisätään palautuvat tiedot tietokantaan
        Tietokanta.addAll(T1.getJasenTiedot());
        Tietokanta.addAll(H1.getJasenTiedot());
        // Tulostetaan seuroilta saadut tiedot
        System.out.println("HaminalahdenMetsästysseura:");
        for (Jasen K :Tietokanta) {
            if (K.getJasenseura().equals("HaminalahdenMetsastysseura"))
                K.tulostaJasenTiedot();
        }
        System.out.println("TurmiolanErä:");
        for (Jasen J :Tietokanta) {
            if (J.getJasenseura().equals("TurmiolanEra"))
                J.tulostaJasenTiedot();
        }
    }
}

